export { matchers } from './client-matchers.js';

export const nodes = [
	() => import('./nodes/0'),
	() => import('./nodes/1'),
	() => import('./nodes/2'),
	() => import('./nodes/3'),
	() => import('./nodes/4'),
	() => import('./nodes/5'),
	() => import('./nodes/6'),
	() => import('./nodes/7'),
	() => import('./nodes/8'),
	() => import('./nodes/9')
];

export const dictionary = {
	"": [[1], [0], 3],
	"about": [[1], [0], 5],
	"map": [[1], [0], 6],
	"todos": [[1], [0], 7, 1],
	"weather": [[1], [0], 8],
	"weather/[location]": [[1], [0], 9],
	"[lang]": [[1], [0,2], 4]
};